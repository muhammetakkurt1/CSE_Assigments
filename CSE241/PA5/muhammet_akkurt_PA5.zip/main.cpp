#include "Robot.h"
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <vector>

using namespace std;

const int GRID_SIZE = 10;			/*Global constants for the size of the grid and the initial number of robots*/
const int INITIAL_COUNT = 5;

Robot *grid[GRID_SIZE][GRID_SIZE] = {nullptr};			/* Grid declaration for the robot objects and whether each robot has moved in the current round*/
bool robotMoved[GRID_SIZE][GRID_SIZE] = {false};


void placeRobotOnGrid(Robot *robot) {			/*Function to place a robot on the grid at a random location that isn't already occupied*/
    int x, y;
    do {
        x = rand() % GRID_SIZE;
        y = rand() % GRID_SIZE;
    } while (grid[x][y] != nullptr);
    grid[x][y] = robot;
    robot->setPosition(x, y);
}

void printArena() {									/*	Function to print the current state of the grid*/
	/*for (int i = 0; i < GRID_SIZE; ++i) {
	    for (int j = 0; j < GRID_SIZE; ++j) {
	        if (grid[i][j] != nullptr) {
	            cout << grid[i][j]->getType().at(0) << " ";
	        } else {
	            cout << "_ ";
	        }
	    }
	cout << endl;		
}

	cout <<"\n";*/
}
void printRemainingRobots(const std::vector<Robot*>& robots) {			/*Function to print the remaining robots that are still alive*/
 /* std::cout << "Remaining robots: " << std::endl;
    std::cout<< "*******************"<<std::endl;
    for (const Robot* robot : robots) {
        if (robot->getHitPoints() > 0) {
        	 
            std::cout << robot->getName() << " (" << robot->getHitPoints() << " HP)" << std::endl;
        }
    }
    std::cout<< "*******************"<<std::endl;   */
}
void moveRobot(Robot& robot) {				/*Function to move a robot to a random adjacent location on the grid if it's unoccupied, or to fight another robot if one is present*/
    srand(time(0));
    int x = robot.getX();
    int y = robot.getY();
    if(robotMoved[x][y]) 				/*If the robot has already moved this turn, don't move it again*/
        return;

    while (true) { 								/* Keep trying to move until a valid move is found or the robot encounters another robot */
        int newX = x;
        int newY = y;
        int direction = rand() % 4;

        switch (direction) {
        case 0:  // up
            newX = x - 1;
            break;
        case 1:  // down
            newX = x + 1;
            break;
        case 2:  // left
            newY = y - 1;
            break;
        case 3:  // right
            newY = y + 1;
            break;
        }

        
        if (newX >= 0 && newX < GRID_SIZE && newY >= 0 && newY < GRID_SIZE) {					/* Check if the new position is valid*/
            if (grid[newX][newY] != nullptr) {
                printArena();			
                if(!robot.fight(*grid[newX][newY])) {											/*If there's another robot, start a fight*/
                    grid[x][y] = nullptr;														/* If the robot lost the fight, delete it from the grid and end its turn*/
                    return;
                }
                if (grid[newX][newY]->getHitPoints() <= 0) {									/* If the robot won the fight, delete the other robot from the grid */
                    grid[newX][newY] = nullptr;
                }
                return;  																	/*Robot has encountered another robot and fought, so it should stop moving*/
            }
            
            grid[x][y] = nullptr;										/*If the spot is empty, move the robot*/
            grid[newX][newY] = &robot;
            robot.setPosition(newX, newY);
            robotMoved[newX][newY] = true; 								/* mark the robot as having moved this turn*/

            printArena();

            x = newX;
            y = newY;
        } 
    }
}



void resetRobotMoved() {											/*Function to reset the robotMoved array to false at the start of each round*/
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            robotMoved[i][j] = false;
        }
    }
}
void runSimulation() {												/*Function to run the robot battle simulation*/
    srand(time(0)); 												/* Initialize random number generator*/

    
    vector<Robot *> robots;											/*Create robots*/
    for (int i = 0; i < INITIAL_COUNT; i++) {
        robots.push_back(new OptimusPrime("optimusPrime_" + to_string(i)));
        robots.push_back(new RoboCop("roboCop_" + to_string(i)));
        robots.push_back(new Roomba("roomba_" + to_string(i)));
        robots.push_back(new Bulldozer("bulldozer_" + to_string(i)));
    }

   
    for (Robot *robot : robots) {			 /*Place robots on grid*/
        placeRobotOnGrid(robot);
    }

    printArena();

   
    while (true) {						/* Run simulation*/
        resetRobotMoved(); 					/* Reset the robotMoved array at the start of each turn*/
	
        Robot* lastRobot = nullptr;			/* Check for remaining robots and declare the winner if only one remains*/
        int remainingRobots = 0;
        for (Robot* robot : robots) {
            if (robot->getHitPoints() > 0) {
            	remainingRobots++;
                lastRobot = robot;
            }
        }
        if (remainingRobots <= 1) {
            if (lastRobot != nullptr) {									/*Print the winner*/
                cout << lastRobot->getName() << " wins the battle!\n";
            } 
            break; 											/*End simulation if one or no robots remain*/
        }

       
        for (Robot *robot : robots) {				 /* Move the robots	*/
            if (robot->getHitPoints() > 0) {
                int otherRobots = 0;						/* Check if there is another robot around before moving the robot*/
                for (Robot *otherRobot : robots) {
                    if (otherRobot->getHitPoints() > 0 && otherRobot != robot) {
                        otherRobots++;
                    }
                }
                if (otherRobots == 0) {						/* If there are no other robots, declare the current robot as the winner and end the simulation */
                    cout << robot->getName() << " wins the battle!\n";
                    return;
                } else {
                    moveRobot(*robot);
					printRemainingRobots(robots);
                }
            }
        }
		
        printArena();
    }

    for (Robot *robot : robots) {			/*delete all robots*/
        delete robot;
    }
}


int main() {
    runSimulation();					/* runs the robot battle simulation*/
    return 0;
}
