#include "robot.h"
#include <iostream>
#include <cstdlib>
#include <ctime>

Robot::Robot(int newStrength, int newHit, std::string newName)					/* Robot constructor*/
    : strength(newStrength), hitpoints(newHit), name(newName), x(-1), y(-1) {}
	
int Robot::getDamage() {													/*Robot's attack action*/
    int damage = (rand() % strength) + 1;									/*Randomly generate a damage value within robot's strength*/
    std::cout << getType() << " attacks for " << damage << " points!" << std::endl;
    return damage;															/* Return the calculated damage*/
}

bool Robot::fight(Robot& victim) {										/*Robot's fight action against another robot (victim)*/
    while (hitpoints > 0 && victim.hitpoints > 0) {						/*Fight until one robot runs out of hitpoints*/
        int damageR = getDamage();										/*Calculate damages for both robots*/
        victim.hitpoints -= damageR;									/*Apply damage to victim*/
        hitMessage(*this, victim, damageR);								/*Display hit message*/
        if (victim.hitpoints <= 0) {
            std::cout << victim.getName() << " is dead." << std::endl;
            return true;												/*If victim is dead, the robot wins*/
        }
        int damageV = victim.getDamage();
        hitpoints -= damageV;											/*Apply damage to the robot*/
        hitMessage(victim, *this, damageV);								/*Display hit message*/
        if (hitpoints <= 0) {
            std::cout << getName() << " is dead." << std::endl;
            return false;												/* If the robot is dead, it loses*/
        }	
    }
    return hitpoints > 0; 												/*Return true if the robot is alive*/
}

void Robot::setPosition(int newX, int newY) {							/*Set robot's position in the arena*/
    x = newX;
    y = newY;
}

int Robot::getX() const {												/*Get robot's x position*/
    return x;
}
	
int Robot::getY() const {												/*Get robot's y position*/
    return y;
}

std::string Robot::getName() const {									/*Get robot's name*/
    return name;
}

int Robot::getHitPoints() const {										/*Get robot's current hitpoints*/
    return hitpoints;
}

void hitMessage(const Robot& attacker, const Robot& victim, int damage) {						/*Display hit message during the fight*/
    std::cout << attacker.getName() << "(" << attacker.getHitPoints() << ") hits "
              << victim.getName() << "(" << victim.getHitPoints() + damage << ") with " << damage << std::endl;
    std::cout << "The new hitpoints of " << victim.getName() << " is " << victim.getHitPoints() << std::endl;
}

Humanic::Humanic(int newStrength, int newHit, std::string newName)					/*Humanic constructor*/
    : Robot(newStrength, newHit, newName) {}
	
std::string Humanic::getType() {										/*Return the type of the robot as "Humanic"*/
    return "Humanic";
}

int Humanic::getDamage() {												/*Humanic's attack action with a chance to launch a special attack*/
    int damage = Robot::getDamage();
    if (rand() % 100 < 10) {											/*10% chance to launch a special attack*/
        damage += 50;													/*Add 50 points to the damage*/
        std::cout << "Tactical nuke attack!" << std::endl;
    }	
    return damage;														/* Return the calculated damage*/
}

OptimusPrime::OptimusPrime(std::string newName) : Humanic(100, 100, newName) {}			/*OptimusPrime class inherits from Humanic*/
	
std::string OptimusPrime::getType() {										/*Returns the robot type as "OptimusPrime"*/
    return "OptimusPrime";
}

int OptimusPrime::getDamage() {											/*OptimusPrime's attack action with a chance to deal double damage*/
    int damage = Humanic::getDamage();
    if (rand() % 100 < 15) {											/*15% chance to deal double damage*/
        damage *= 2;													/*Double the damage*/
        std::cout << "Double damage!" << std::endl;
    }	
    return damage;														/* Return the calculated damage*/
}

RoboCop::RoboCop(std::string newName) : Humanic(30, 40, newName) {}		/*RoboCop class inherits from Humanic*/

std::string RoboCop::getType() {										/*Returns the robot type as "RoboCop"*/
    return "RoboCop";
}

Roomba::Roomba(std::string newName) : Robot(3, 10, newName) {}			/*Roomba class inherits from Robot*/

std::string Roomba::getType() {											/*Returns the robot type as "Roomba"*/
    return "Roomba";
}

int Roomba::getDamage() {												/*Roomba's attack action with a chance to attack twice*/
    int damage = Robot::getDamage();
    int secondAttack = (rand() % strength) + 1;							/* Generate damage for the second attack*/
    std::cout << "Roomba attacks twice! Second attack for " << secondAttack << " points!" << std::endl;
    damage += secondAttack;												/*Total damage is the sum of the two attacks*/
    return damage;														/* Return the calculated damage*/
}
	
Bulldozer::Bulldozer(std::string newName) : Robot(50, 200, newName) {}	 /*Bulldozer class inherits from Robot*/

std::string Bulldozer::getType() {										/*Returns the robot type as "Bulldozer"*/
    return "Bulldozer";	
}

