#ifndef ROBOT_H
#define ROBOT_H

#include <string>

class Robot {
protected:								 /*Each robot has a strength, hitpoints, name and a position (x, y)*/
    int strength;
    int hitpoints;
    std::string name;
    int x, y;

public:
    Robot(int newStrength, int newHit, std::string newName);
    virtual ~Robot() {}														/*Virtual destructor, which does nothing here but is required due to the presence of virtual functions*/

    virtual std::string getType() = 0;										/*Pure virtual function to return the type of the robot*/

    virtual int getDamage();												/*Virtual function to return the damage dealt by the robot*/

    bool fight(Robot& victim);												/* Function to simulate a fight between this robot and another*/

    void setPosition(int newX, int newY);									/*Function to set the position of the robot*/

    int getX() const;														/*Getter functions*/
    int getY() const;
    std::string getName() const;
    int getHitPoints() const;
};
void hitMessage(const Robot& attacker, const Robot& victim, int damage);	/*Helper function to print a message when a robot hits another*/

class Humanic : public Robot {												/*Derived class for "Humanic" robots*/
public:
    Humanic(int newStrength, int newHit, std::string newName);				/*Constructor for Humanic class*/
    ~Humanic() {}															/*Destructor for Humanic class*/

    std::string getType() override;											 /*Function to return the type of the robot*/
    int getDamage() override;											 	/* Function to return the damage dealt by the robot*/
};

class OptimusPrime : public Humanic {										/*Derived class for "OptimusPrime" robots*/
public:
    OptimusPrime(std::string newName);										/*Constructor for OptimusPrime class*/
    ~OptimusPrime() {}														/* Destructor for OptimusPrime class*/

    std::string getType() override;											/*Function to return the type of the robot*/
    int getDamage() override;												/*Function to return the damage dealt by the robot*/
};

class RoboCop : public Humanic {											/*Derived class for "RoboCop" robots*/
public:
    RoboCop(std::string newName);											/*Constructor for RoboCop class*/
    ~RoboCop() {}															/* Destructor for RoboCop class*/

    std::string getType() override;											/*Function to return the type of the robot*/
};

class Roomba : public Robot {												/*Derived class for "Roomba" robots*/
public:
    Roomba(std::string newName);											/*Constructor for Roomba class*/
    ~Roomba() {}															/*Destructor for Roomba class*/

    std::string getType() override;											/*Function to return the type of the robot*/
    int getDamage() override;												/*Function to return the damage dealt by the robot*/
};

class Bulldozer : public Robot {											/* Derived class for "Bulldozer" robots*/
public:
    Bulldozer(std::string newName);											/*Constructor for Bulldozer class*/
    ~Bulldozer() {}															/*Destructor for Bulldozer class*/

    std::string getType() override;											/*Function to return the type of the robot*/
};

#endif

