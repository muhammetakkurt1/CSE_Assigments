import java.util.*;
	
interface Visual {}				/*Interfaces for Visual, NonVisual, Playable, and NonPlayable for categorizing dataset objects*/

interface NonVisual {}

interface Playable {
    void play();
}

interface NonPlayable {
    void view();
}

abstract class DatasetObject {				/*DatasetObject is an abstract class that represents an object in the dataset*/
    private String name;
    private String additionalInfo;

    public DatasetObject(String name, String additionalInfo) {
        this.name = name;
        this.additionalInfo = additionalInfo;
    }

    public String getName() {			/*Accessor method to get the object's name*/
        return this.name;
    }

    public String getAdditionalInfo() {			/*Accessor method to get the object's additional info*/
        return this.additionalInfo;
    }
}

class Text extends DatasetObject implements NonVisual, NonPlayable {		/*Text class extends the DatasetObject abstract class and implements NonVisual and NonPlayable interfaces*/
    public Text(String name, String otherInfo) {							/*Constructor for the Text class */
        super(name, otherInfo);												/*Calls the superclass constructor (from DatasetObject) to initialize these values*/
    }

    @Override												/* Overrides the view method from the NonPlayable interface */
    public void view() {									 /*This is the functionality that will be performed when a Text object is viewed*/
        System.out.println("Viewing text: " + getName());
    }
}

class Audio extends DatasetObject implements NonVisual, Playable {			/*Audio class extends the DatasetObject abstract class and implements NonVisual and Playable interfaces*/
    public Audio(String name, String duration, String otherInfo) {			/* Constructor for the Audio class*/
        super(name, otherInfo + "; Duration: " + duration);					/*Calls the superclass constructor (from DatasetObject) to initialize these values*/
    }

    @Override												/*Overrides the play method from the Playable interface.*/
    public void play() {									/* This is the functionality that will be performed when an Audio object is played*/
        System.out.println("Playing audio: " + getName());
    }
}

class Video extends DatasetObject implements Visual, Playable {			/*Video class extends the DatasetObject abstract class and implements Visual and Playable interfaces*/
    public Video(String name, String duration, String otherInfo) {		/*Constructor for the Video class. Accepts a name, duration and additional information*/
        super(name, otherInfo + "; Duration: " + duration);				/*Calls the superclass constructor (from DatasetObject) to initialize these values*/
    }

    @Override															/* Overrides the play method from the Playable interface.*/
    public void play() {												/*This is the functionality that will be performed when a Video object is played.*/
        System.out.println("Playing video: " + getName());
    }
}


class Image extends DatasetObject implements Visual, NonPlayable {		/*Image class extends the DatasetObject abstract class and implements Visual and NonPlayable interfaces*/
    public Image(String name, String dimensions, String otherInfo) {	/*Constructor for the Image class. Accepts a name, dimensions, and additional information*/
        super(name, otherInfo + "; Dimensions: " + dimensions);			/*Calls the superclass constructor (from DatasetObject) to initialize these values*/
    }

    @Override															/*Overrides the view method from the NonPlayable interface*/
    public void view() {												/*This is the functionality that will be performed when an Image object is viewed*/	
        System.out.println("Viewing image: " + getName());	
    }
}

interface Observer {					/* Observer interface defines two methods for any class that wants to observe changes to the Dataset.*/
    void update(DatasetObject obj);		/*Called when a new DatasetObject is added to the Dataset*/
    void remove(DatasetObject obj);		/*Called when a DatasetObject is removed from the Dataset*/
}

class Dataset {								/*Dataset class manages a collection of DatasetObjects and a list of Observers*/
    private List<Observer> observers;					/*A list of Observers to be notified when the Dataset changes*/
    private List<DatasetObject> datasetObjects;			/*A list of DatasetObjects managed by this Dataset*/

    public Dataset() {									/*Dataset constructor initializes the lists of Observers and DatasetObjects*/
        observers = new ArrayList<>();
        datasetObjects = new ArrayList<>();
    }

    public void register(Observer observer) {			/* Adds an Observer to the list of Observers to be notified when the Dataset changes*/
        observers.add(observer);
    }

    public void unregister(Observer observer) {			/*Removes an Observer from the list of Observers to be notified when the Dataset changes*/
        observers.remove(observer);
    }

    public void add(DatasetObject obj) {				/*Adds a DatasetObject to the Dataset and notifies all Observers of the addition*/
        datasetObjects.add(obj);
        notifyObservers(obj);
    }

    public void remove(String name) {					/*Removes a DatasetObject from the Dataset by name and notifies all Observers of the removal*/
        DatasetObject toRemove = null;
        for (DatasetObject obj : datasetObjects) {
            if (obj.getName().equals(name)) {
                toRemove = obj;
                break;
            }
        }
        if (toRemove != null) {
            datasetObjects.remove(toRemove);
            notifyObserversRemove(toRemove);
        }
    }


    private void notifyObservers(DatasetObject obj) {	/*Notifies all Observers that a DatasetObject has been added to the Dataset*/
        for (Observer observer : observers) {
            observer.update(obj);
        }
    }

    private void notifyObserversRemove(DatasetObject obj) {			/*Notifies all Observers that a DatasetObject has been removed from the Dataset*/
        for (Observer observer : observers) {
            observer.remove(obj);
        }
    }
}

class Player implements Observer {					/*The Player class implements the Observer interface and manages a playlist of Playable objects*/
    private List<Playable> playlist;				/*Define a list to store Playable objects*/
    private int currentlyPlayingIndex;				/*An integer to store the index of the currently playing Playable object in the playlist*/

    public Player() {								/*Constructor method for Player class. Initializes an empty list for playlist and sets currentlyPlayingIndex to -1 indicating no object is playing yet*/
        playlist = new ArrayList<>();
        currentlyPlayingIndex = -1;
    }

    @Override
    public void update(DatasetObject obj) {			/*Called when a DatasetObject is added to the Dataset. If the object is Playable, it is added to the playlist*/
        if (obj instanceof Playable) {
            playlist.add((Playable) obj);
            if (currentlyPlayingIndex == -1) {		/*If nothing was playing before, start playing this new object*/
                currentlyPlayingIndex = 0;
                playlist.get(0).play();
            }
        }
    }

    @Override
    public void remove(DatasetObject obj) {			/*Called when a DatasetObject is removed from the Dataset. If the object is Playable, it is removed from the playlist*/
        if (obj instanceof Playable) {
            int index = playlist.indexOf(obj);
            playlist.remove(obj);
            if (playlist.isEmpty()) {				/*If playlist is empty after removal, set currentlyPlayingIndex to -1 indicating nothing is playing*/
                currentlyPlayingIndex = -1;
            } else if (index <= currentlyPlayingIndex) {	/*If the removed object was playing or any object before it was playing, decrease currentlyPlayingIndex by 1*/
                currentlyPlayingIndex--;
            }
        }
    }

    public Playable currently_playing() {			/*Returns the currently playing Playable object. If nothing is playing, a dummy Audio object is returned*/
        if (currentlyPlayingIndex == -1) {
            return new Audio("No audio", "0min", "");  /* a dummy object */
        }
        return playlist.get(currentlyPlayingIndex);
    }

    public void next(String type) {					/*Moves to the next Playable object of the specified type in the playlist and starts playing it*/
        int newIndex = currentlyPlayingIndex + 1;	/* Set newIndex to the next index in the playlist*/
        while (newIndex < playlist.size()) {		/* Loop through the playlist starting from the next index*/
            if (playlist.get(newIndex).getClass().getSimpleName().toLowerCase().equals(type)) {	/*If a Playable object of the specified type is found, start playing it and update the currentlyPlayingIndex*/
                currentlyPlayingIndex = newIndex;
                playlist.get(currentlyPlayingIndex).play();
                return;
            }
            newIndex++;							/*Move to the next index in the playlist*/
        }
        throw new RuntimeException("No next object of type " + type + " to play!");		/*If no Playable object of the specified type is found, throw an exception*/
    }

    public void previous(String type) {				/*Moves to the previous Playable object of the specified type in the playlist and starts playing it*/
        int newIndex = currentlyPlayingIndex - 1;		/*Set newIndex to the previous index in the playlist*/
        while (newIndex >= 0) {							/*Loop through the playlist starting from the previous index and going backwards*/
            if (playlist.get(newIndex).getClass().getSimpleName().toLowerCase().equals(type)) {	/*If a Playable object of the specified type is found, start playing it and update the currentlyPlayingIndex*/
                currentlyPlayingIndex = newIndex;
                playlist.get(currentlyPlayingIndex).play();
                return;
            }
            newIndex--;							/*Move to the previous index in the playlist*/
        }
        throw new RuntimeException("No previous object of type " + type + " to play!");		/*If no Playable object of the specified type is found, throw an exception*/
    }

    public void show_list() {						/*Prints the names of all Playable objects in the playlist*/
        System.out.println("Current playlist:");
        for (Playable p : playlist) {				/*Loop through each Playable object in the playlist*/
            if (p instanceof DatasetObject) {		/*If the Playable object is also a DatasetObject, print its name*/
                System.out.println(((DatasetObject) p).getName());
            }
        }
    }
}

class Viewer implements Observer {				/*The Viewer class implements the Observer interface and manages a list of NonPlayable objects*/
    private List<NonPlayable> viewlist;			/*Define a list to store NonPlayable objects*/
    private int currentlyViewingIndex;			/*An integer to store the index of the currently viewing NonPlayable object in the viewlist*/

    public Viewer() {							/*Constructor method for Viewer class. Initializes an empty list for viewlist and sets currentlyViewingIndex to -1 indicating no object is being viewed yet*/
        viewlist = new ArrayList<>();
        currentlyViewingIndex = -1;
    }

    @Override
    public void update(DatasetObject obj) {		/*Called when a DatasetObject is added to the Dataset. If the object is NonPlayable, it is added to the viewlist*/
        if (obj instanceof NonPlayable) {
            viewlist.add((NonPlayable) obj);
            if (currentlyViewingIndex == -1) {		/* If nothing was being viewed before, start viewing this new object*/
                currentlyViewingIndex = 0;
                viewlist.get(0).view();
            }
        }
    }

    @Override
    public void remove(DatasetObject obj) {		/*Called when a DatasetObject is removed from the Dataset. If the object is NonPlayable, it is removed from the viewlist*/
        if (obj instanceof NonPlayable) {
            int index = viewlist.indexOf(obj);
            viewlist.remove(obj);
            if (viewlist.isEmpty()) {				/*If viewlist is empty after removal, set currentlyViewingIndex to -1 indicating nothing is being viewed*/
                currentlyViewingIndex = -1;
            } else if (index <= currentlyViewingIndex) {	/*If the removed object was being viewed or any object before it was being viewed, decrease currentlyViewingIndex by 1*/
                currentlyViewingIndex--;
            }
        }
    }

    public NonPlayable currently_viewing() {	/*Returns the currently viewing NonPlayable object. If nothing is being viewed, a dummy Text object is returned*/
        if (currentlyViewingIndex == -1) {
            return new Text("No text", "");  /* a dummy object */
        }
        return viewlist.get(currentlyViewingIndex);
    }
    
    public void next(String type) {					/*Moves to the next NonPlayable object of the specified type in the viewlist and starts viewing it*/
        int newIndex = currentlyViewingIndex + 1;				/* Increase the index of the currently viewing object by one to start from the next object*/
        while (newIndex < viewlist.size()) {					/*Loop through the remaining objects in the viewlist*/
            if (viewlist.get(newIndex).getClass().getSimpleName().toLowerCase().equals(type)) {		/*Check if the current object's type matches the required type*/
                currentlyViewingIndex = newIndex;									/*If a match is found, update the currently viewing index to the new index*/
                viewlist.get(currentlyViewingIndex).view();							/*Start viewing the new object*/
                return;
            }
            newIndex++;													/* Move to the next object in the viewlist if the current object's type did not match*/
        }
        throw new RuntimeException("No next object of type " + type + " to view!");		/* Throw an exception if no object of the required type could be found in the remaining viewlist*/
    }

    public void previous(String type) {				/*Moves to the previous NonPlayable object of the specified type in the viewlist and starts viewing it*/
        int newIndex = currentlyViewingIndex - 1;				/*Decrease the index of the currently viewing object by one to start from the previous object*/
        while (newIndex >= 0) {									/*Loop through the previous objects in the viewlist in reverse order*/
            if (viewlist.get(newIndex).getClass().getSimpleName().toLowerCase().equals(type)) {	/*Check if the current object's type matches the required type*/
                currentlyViewingIndex = newIndex;						/*If a match is found, update the currently viewing index to the new index*/
                viewlist.get(currentlyViewingIndex).view();				/* Start viewing the new object*/
                return;
            }
            newIndex--;										/*Move to the previous object in the viewlist if the current object's type did not match*/
        }
        throw new RuntimeException("No previous object of type " + type + " to view!");		/*Throw an exception if no object of the required type could be found in the previous viewlist*/
    }
    public void show_list() {						/*Prints the names of all NonPlayable objects in the viewlist*/
        System.out.println("Current viewlist:");
        for (NonPlayable np : viewlist) {			/*Loop through each NonPlayable object in the viewlist*/
            if (np instanceof DatasetObject) {		/*If the NonPlayable object is also a DatasetObject, print its name*/
                System.out.println(((DatasetObject) np).getName());
            }
        }
    }
}

public class main {										/*The main class, which is our starting point*/
    public static void main(String[] args) {
    	 Dataset ds = new Dataset();			/*create a dataset*/

         Player p1 = new Player();				/*create a player and a viewer*/
         Viewer v1 = new Viewer();

         ds.register(p1);						/*register the player and the viewer in the dataset*/
         ds.register(v1);						/*This way they can get notified when something changes in the dataset*/

         ds.add(new Audio("audioname1", "2min", "info about audio1"));			/*add some objects to the dataset*/
         ds.add(new Text("textname1", "info about text1"));						/*In this case, we add several different objects of each type*/
         ds.add(new Video("videoname1", "5min", "info about video1"));
         ds.add(new Image("imagename1", "800x600", "info about image1"));
         ds.add(new Audio("audioname2", "4min", "info about audio2"));
         
         System.out.println();									
         p1.show_list();														/*viewing the current listings of the player and the viewer*/
         v1.show_list();

         System.out.println("\nRemoving audioname1");
         ds.remove("audioname1");												/*remove an object from the dataset*/
         
         System.out.println();
         p1.show_list();														/*view the lists again*/
         v1.show_list();

         System.out.println("\nAdding audioname3");
         ds.add(new Audio("audioname3", "3min", "info about audio3"));			/*Adding a new object to the dataset*/
         
         System.out.println();
         p1.show_list();														/*view the lists again*/
         v1.show_list();

         System.out.println("\nPlaying next audio");
         p1.next("audio");														/*play the next audio item and view what is currently playing/watching*/
         System.out.println("Currently playing: " + ((DatasetObject)p1.currently_playing()).getName());
         System.out.println("Currently viewing: " + ((DatasetObject)v1.currently_viewing()).getName());
         
         System.out.println("\nViewing next image");
         try {												
             v1.next("image");													/*display the next image*/
             System.out.println("Currently viewing: " + ((DatasetObject)v1.currently_viewing()).getName());
         } catch (RuntimeException ex) {
             System.out.println(ex.getMessage());
         }


         System.out.println("\nAdding another image and text");
         ds.add(new Image("imagename2", "1024x768", "info about image2"));		/*add another image and text to the dataset*/
         ds.add(new Text("textname2", "info about text2"));
         
         System.out.println();
         v1.show_list();														/*display the viewer's list again*/

         System.out.println("\nViewing next image");
         v1.next("image");														/*display the next image*/

         System.out.println("\nRemoving all data");
         ds.remove("videoname1");												/*remove all data from the dataset*/
         ds.remove("textname1");
         ds.remove("imagename1");
         ds.remove("audioname2");
         ds.remove("audioname3");
         ds.remove("textname2");
         ds.remove("imagename2");

         p1.show_list();														/*displaying the player and viewer lists again*/
         v1.show_list();
    }
}

