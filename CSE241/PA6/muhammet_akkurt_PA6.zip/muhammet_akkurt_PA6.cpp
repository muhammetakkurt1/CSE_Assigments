#include <iostream>
#include <algorithm>
#include <fstream>
#include <map>
#include <sstream>
#include <string>
#include <vector>


class Entry {						/*Entry class represents an entry in the catalog*/
public:
    std::string title;				/*These fields represent the data for an entry*/	
    std::string creator;
    std::string year;
    std::string genre_tags;
    std::string starring;
    
	bool hasTitle;					/*These boolean flags indicate whether the corresponding field is present in the entry*/
    bool hasCreator;
    bool hasYear;
    bool hasGenreTags;
    bool hasStarring;

	/*Default constructor initializes fields to an empty state*/
    Entry() : title(""), creator(""), year(""), genre_tags(""), starring(""),	
              hasTitle(false), hasCreator(false), hasYear(false), hasGenreTags(false), hasStarring(false) {}
              
	std::string toString() const;			/*toString method formats the entry as a string*/
};


std::string Entry::toString() const {			/*toString method implementation*/
    std::vector<std::string> fields;			/*Define vector to hold fields of the Entry*/
	
    if(hasTitle) {								/*Each field is added to the fields vector if it is present*/
        fields.push_back("\"" + title + "\"");
    }

    if(hasCreator) {							
        fields.push_back("\"" + creator + "\"");
    }

    if(hasYear) {
        fields.push_back("\"" + year + "\"");
    }

    if(hasGenreTags) {
        fields.push_back("\"" + genre_tags + "\"");
    }

    if (hasStarring) {
        fields.push_back("\"" + starring + "\"");
    }

    std::string output = "";						/*Define output string to hold final result*/
    for (size_t i = 0; i < fields.size(); ++i) {	/*Iterate over each field in fields vector*/
        output += fields[i];						/*Add each field to output string*/
        if (i < fields.size() - 1) {				/*Add a space after each field (except last one) to separate fields*/
            output += " ";	
        }
    }

    return output;									/*Return final output string*/
}

	
class Logger {												/*Logger class provides functionality for writing messages to a log file*/
public:
    Logger(const std::string& filename) : file(filename, std::ios::out) {			/*Constructor opens the log file*/
        if (!file) {																/*If the log file can't be opened, a runtime error is thrown*/
            throw std::runtime_error("Cannot open log file: " + filename);
        }
    }

    void log(const std::string& message) {											/*The log method writes a message to the log file*/
        file << message << "\n";
    }

    void logError(const std::string& error, const Entry& entry) {					/*The logError method writes an error message and the related entry to the log file*/
        file << error << "\n" << entry.toString() << "\n";
    }

private:
    std::ofstream file;															/*The log file stream*/
};


class BaseException {															/* Base exception class*/
public:
    BaseException(const std::string& message) : message_(message) {}

    const std::string& what() const {											/*Getter for the error message*/
        return message_;		
    }

private:
    std::string message_;														/* Variable to store the error message*/
};	

class MissingFieldException : public BaseException {							/*Exception for missing fields, inherits from BaseException*/
public:
    MissingFieldException(const std::string& message = "Exception: missing field")		/* Default message is "Exception: missing field" */
        : BaseException(message) {}
};

class DuplicateEntryException : public BaseException {
public:
    DuplicateEntryException(const std::string& message = "Exception: duplicate entry")			/* Default message is "Exception: duplicate entry" */
        : BaseException(message) {}
};

class WrongCommandException : public BaseException {
public:
    WrongCommandException(const std::string& message = "Exception: command is wrong")			/* Default message is "Exception: command is wrong" */
        : BaseException(message) {}
};


class Catalog {																/*Base Catalog class*/
public:
    Catalog(const std::string& logFilename) : logger(logFilename) {}		/*Constructor which takes the filename of the log file*/
	
	std::string getCatalogType() const { return catalogType; }				/*Getter for catalog type*/
    void setCatalogType(const std::string& type) {							/*Setter for catalog type*/
        this->catalogType = type;
    }
    
    virtual void search(const std::string& term, const std::string& field) = 0;		/*Pure virtual method for searching entries*/
    virtual bool sort(const std::string& field) = 0;												/*Pure virtual method for sorting entries*/
    virtual ~Catalog() {}
	void readCatalog(const std::string& filename);													/*Method to read a catalog from a file, to be implemented*/
    void log(const std::string& message) { logger.log(message); }									/* Method for logging messages to the logger*/

protected:
    std::vector<Entry> entries;																		/*Vector to store all entries*/
    Logger logger;																					/*Logger object for logging messages*/
    std::string catalogType;																		/*String to store the catalog type*/
};

						
class MovieCatalog : public Catalog {				/*MovieCatalog class, inherits from Catalog*/												
public:
    MovieCatalog(const std::string& logFilename) : Catalog(logFilename) {}						/*Constructor which takes the filename of the log file*/

    void search(const std::string& term, const std::string& field) override;		/*Implementation of the search method*/
    bool sort(const std::string& field) override;												/*Implementation of the sort method*/
};

	
class BookCatalog : public Catalog {				/*BookCatalog class, inherits from Catalog*/		
public:
    BookCatalog(const std::string& logFilename) : Catalog(logFilename) {}						/*Constructor which takes the filename of the log file*/

    void search(const std::string& term, const std::string& field) override;		/*Implementation of the search method*/
    bool sort(const std::string& field) override;												/*Implementation of the sort method*/
};

	
class MusicCatalog : public Catalog {				/* MusicCatalog class, inherits from Catalog*/
public:
    MusicCatalog(const std::string& logFilename) : Catalog(logFilename) {}						/*Constructor which takes the filename of the log file*/	

    void search(const std::string& term, const std::string& field) override;		/*Implementation of the search method*/
    bool sort(const std::string& field) override;												/*Implementation of the sort method*/
};


void Catalog::readCatalog(const std::string& filename) {
    std::ifstream file(filename);										/*Open the file*/
    if (!file) {														/*Throw an exception if the file cannot be opened*/
        throw std::runtime_error("Cannot open file: " + filename);				
    }

    std::string line;
    std::map<std::string, int> entry_titles;							/* Map to keep track of the titles of entries*/
    
    if (getline(file, catalogType)) {									/*Read the first line which contains the catalog type*/
        logger.log("Catalog Read: " + catalogType);						/*Log the type of the catalog*/
    }

    std::map<std::string, int> entry_data;								/*Map to keep track of the complete entry data*/
	
    while (getline(file, line)) {										/*Loop over all lines in the file*/
        Entry entry;													/*Create a new entry object*/
        std::stringstream ss(line);
        std::string title, creator, year, genre_tags, starring;
		
				/*Extract each field from the line*/														
        entry.hasTitle = static_cast<bool>(getline(ss, title, '"'));
        entry.hasTitle = static_cast<bool>(getline(ss, title, '"'));
        ss.ignore(2);													/* Ignore the field separator*/
        entry.hasCreator = static_cast<bool>(getline(ss, creator, '"'));
        ss.ignore(2);													/* Ignore the field separator*/	
        entry.hasYear = static_cast<bool>(getline(ss, year, '"'));
        ss.ignore(2);													/* Ignore the field separator*/	
        entry.hasGenreTags = static_cast<bool>(getline(ss, genre_tags, '"'));
        ss.ignore(2);													/* Ignore the field separator*/	

        if(catalogType.substr(0,5) == "movie") {						/*Check if the catalog type is 'movie' and if so, extract the starring field*/
            entry.hasStarring = static_cast<bool>(getline(ss, starring, '"'));
            entry.starring = starring;
        }
				
				/*Store the extracted fields in the entry object*/
        entry.title = title;
        entry.creator = creator;
        entry.year = year;
        entry.genre_tags = genre_tags;
					
					/*Check if any of the required fields are missing, and if so, log the error and skip to the next entry*/
        if(catalogType.substr(0,5) == "movie" && (!entry.hasTitle || !entry.hasCreator || !entry.hasYear || !entry.hasGenreTags || !entry.hasStarring)) {
            logger.logError(MissingFieldException().what(), entry);
            continue;
        }
        else if (catalogType.substr(0,5) != "movie" && (!entry.hasTitle || !entry.hasCreator || !entry.hasYear || !entry.hasGenreTags)) {
            logger.logError(MissingFieldException().what(), entry);
            continue;
        } 
					
        std::string entry_key = title + creator + year + genre_tags;			/*Create a key by concatenating all the fields of the entry*/
					
        if(catalogType.substr(0,5) == "movie") {								/*If it's a movie, also include the starring field in the key*/
            entry_key += starring;
        }
					
        if (entry_data.count(entry_key) > 0 || entry_titles[title] > 0) {		/*Check if this entry already exists in the catalog, and if so, log the error and skip to the next entry*/
            logger.logError(DuplicateEntryException().what(), entry);
            continue;
        }
					/*If the entry is unique, add it to the entry data map and entries vector*/
        entry_data[entry_key]++;
        entry_titles[title]++;
        entries.push_back(entry);
    }

    							
    logger.log(std::to_string(entries.size()) + " unique entries");			/* Log the number of unique entries that were read from the file*/
}



void MovieCatalog::search(const std::string& term, const std::string& field) {										/*MovieCatalog search function*/

    if (field != "title" && field != "director" && field != "year" && field != "genre" && field != "starring") {	/* Checking if the field is valid for this catalog type*/
        throw WrongCommandException();																				/*If not, throw an exception*/
    }
  	logger.log("search \"" + term + "\" in \"" + field + "\"");														/*Logging the search operation*/
    bool foundMatch = false;																						/*Flag to check if any matches are found during search*/
    for (const Entry& entry : entries) {																			/*Iterating over all entries in the catalog*/
        if ((field == "title" && entry.title.find(term) != std::string::npos) ||								/*If the term is found in the given field of the entry*/
            (field == "director" && entry.creator.find(term) != std::string::npos) ||
            (field == "year" && entry.year.find(term) != std::string::npos) ||
            (field == "genre" && entry.genre_tags.find(term) != std::string::npos) ||
            (field == "starring" && entry.starring.find(term) != std::string::npos)) 
		{
            logger.log(entry.toString());												/* log the entry and mark the match as found*/
            foundMatch = true;
        }
    }

    if (!foundMatch) {					/*If no matches were found during the search, log that no matches were found*/
        logger.log("found no matches");
    }
}

void BookCatalog::search(const std::string& term, const std::string& field) {                       /*BookCatalog search function*/
   
    if (field != "title" && field != "authors" && field != "year" && field != "tags") {				/* Checking if the field is valid for this catalog type*/
        throw WrongCommandException();																/*If not, throw an exception*/
    }
	logger.log("search \"" + term + "\" in \"" + field + "\"");										/*Logging the search operation*/
    bool foundMatch = false;																		/*Flag to check if any matches are found during search*/	
    for (const Entry& entry : entries) {															/*Iterating over all entries in the catalog*/
        if ((field == "title" && entry.title.find(term) != std::string::npos) ||					/*If the term is found in the given field of the entry*/
            (field == "authors" && entry.creator.find(term) != std::string::npos) ||
            (field == "year" && entry.year.find(term) != std::string::npos) ||
            (field == "tags" && entry.genre_tags.find(term) != std::string::npos)) 
		{
            logger.log(entry.toString());															/* log the entry and mark the match as found*/
            foundMatch = true;
        }
    }

    if (!foundMatch) {					/*If no matches were found during the search, log that no matches were found*/												
        logger.log("found no matches");
    }
}

void MusicCatalog::search(const std::string& term, const std::string& field) {						/*MusicCatalog search function*/
   
    if (field != "title" && field != "artists" && field != "year" && field != "genre") {			/* Checking if the field is valid for this catalog type*/	
        throw WrongCommandException();																/*If not, throw an exception*/
    }
	logger.log("search \"" + term + "\" in \"" + field + "\"");										/*Logging the search operation*/
    bool foundMatch = false;																		/*Flag to check if any matches are found during search*/
    for (const Entry& entry : entries) {															/*Iterating over all entries in the catalog*/
        if ((field == "title" && entry.title.find(term) != std::string::npos) ||					/*If the term is found in the given field of the entry*/
            (field == "artists" && entry.creator.find(term) != std::string::npos) ||
            (field == "year" && entry.year.find(term) != std::string::npos) ||
            (field == "genre" && entry.genre_tags.find(term) != std::string::npos)) 
		{
            logger.log(entry.toString());															/* log the entry and mark the match as found*/
            foundMatch = true;
        }
    }


    if (!foundMatch) {					/*If no matches were found during the search, log that no matches were found*/	
        logger.log("found no matches");
    }
}


bool MovieCatalog::sort(const std::string& field) {									/*Function to sort the MovieCatalog by a specified field*/
    if (field == "title") {															/*Sorting based on the field specified. If the field doesn't match any known fields, return false.*/
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by title in ascending order*/
            return a.title < b.title;
        });
    }
    else if (field == "director") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by director's name in ascending order*/	
            return a.creator < b.creator;
        });
    }
    else if (field == "year") {															
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by release year in ascending order*/
            return a.year < b.year;
        });
    }
    else if (field == "genre") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by genre in ascending order*/
            return a.genre_tags < b.genre_tags;
        });
    }
    else if (field == "starring") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by starring actor in ascending order*/
            return a.starring < b.starring;
        });
    }
    else {
        return false;													/*If the field doesn't match any of the known fields, return false to indicate failure*/
    }

    logger.log("sort \"" + field + "\"");								/*Log the sorting operation*/
    for (const Entry& entry : entries) {
        logger.log(entry.toString());
    }

    return true;														/* Return true to indicate success*/
}
	
bool BookCatalog::sort(const std::string& field) {								/*Function to sort the BookCatalog by a specified field*/
    if (field == "title") {														/*Sorting based on the field specified. If the field doesn't match any known fields, return false.*/
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by title in ascending order*/
            return a.title < b.title;
        });
    }
    else if (field == "authors") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by author's name in ascending order*/
            return a.creator < b.creator;
        });
    }
    else if (field == "year") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by release year in ascending order*/	
            return a.year < b.year;
        });
    }
    else if (field == "tags") {
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by tags in ascending order*/
            return a.genre_tags < b.genre_tags;
        });
    }
    else {																		
        return false;													/*If the field doesn't match any of the known fields, return false to indicate failure*/
    }

    logger.log("sort \"" + field + "\"");								/*Log the sorting operation*/
    for (const Entry& entry : entries) {								/* Log each entry in the sorted catalog*/
        logger.log(entry.toString());
    }

    return true;														/* Return true to indicate success*/
}

bool MusicCatalog::sort(const std::string& field) {					/*Function to sort the MusicCatalog by a specified field*/
    if (field == "title") {											/*Sorting based on the field specified. If the field doesn't match any known fields, return false.*/
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {			/*Sorting by title in ascending order*/
            return a.title < b.title;
        });
    }
    else if (field == "artists") {																/*Sorting by artist's name in ascending order*/
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
            return a.creator < b.creator;
        });
    }
    else if (field == "year") {																	/*Sorting by release year in ascending order*/	
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
            return a.year < b.year;
        });
    }
    else if (field == "genre") {																/*Sorting by genre in ascending order*/
        std::sort(entries.begin(), entries.end(), [](const Entry& a, const Entry& b) {
            return a.genre_tags < b.genre_tags;
        });
    }
    else {	
        return false;																		/*If the field doesn't match any of the known fields, return false to indicate failure*/
    }
	
    logger.log("sort \"" + field + "\"");													/*Log the sorting operation*/
    for (const Entry& entry : entries) {													/* Log each entry in the sorted catalog*/
        logger.log(entry.toString());
    }

    return true;																			/* Return true to indicate success*/
}

void processCommands(const std::string& filename, Catalog& catalog) {			/*reads a list of commands from a file and executes them*/
    std::ifstream file(filename);												/*Open the command file*/
    if (!file) {	
        throw std::runtime_error("Cannot open file: " + filename);				/*If the file could not be opened, throw an exception*/
    }

    std::string line;
    while (getline(file, line)) {							/*Process each line in the file*/
        std::stringstream ss(line);							/*Use a stringstream to split the line into words*/
        std::string command;							
        ss >> command;											/*Read the first word on the line (the command)*/

        if (command == "search") {								/*If the command is "search", read the search term and field*/
            std::string term, field;
            ss.ignore(2);
            getline(ss, term, '"');
            ss.ignore(5);
            getline(ss, field, '"');

            try {										/*Try to execute the search command*/
                catalog.search(term, field);
            } catch (const WrongCommandException& e) {			/*If the command was invalid, log the error*/
                catalog.log(std::string(e.what()) + "\n" + line); 
            }
        } else if (command == "sort") {					/*If the command is "sort", read the sort field*/
		    std::string field;
		    ss.ignore(2);
		    getline(ss, field, '"');
		
		    if (!catalog.sort(field)) {			/*If the command was invalid, log the error*/
		        catalog.log(std::string(WrongCommandException().what()) + "\n" + line);
		    }
		} else {							/*If the command was unrecognized, log the error*/
            catalog.log(std::string(WrongCommandException().what()) + "\n" + line); // Corrected
        }
    }
}

int main() {
    Catalog* catalog = nullptr;								/* Create a pointer to a Catalog object*/
    const std::string OUTPUT_FILE = "output.txt";
    const std::string DATA_FILE = "data.txt";
    const std::string COMMANDS_FILE = "commands.txt";
    
    std::ifstream dataFile(DATA_FILE);					/*Open the data file and read the first line to determine the catalog type*/
    std::string firstLine;
    std::getline(dataFile, firstLine);
    
    if(firstLine.substr(0,5) == "movie")				/* Create the appropriate type of Catalog based on the first line*/
        catalog = new MovieCatalog(OUTPUT_FILE);
	else if(firstLine.substr(0,4) == "book")
        catalog = new BookCatalog(OUTPUT_FILE);
    else if(firstLine.substr(0,5) == "music")
        catalog = new MusicCatalog(OUTPUT_FILE);
    
    if (catalog != nullptr) {							/*If a catalog was successfully created*/
        catalog->readCatalog(DATA_FILE);				/*Read the data into the catalog*/
        processCommands(COMMANDS_FILE, *catalog);		/*Process the commands in the command file*/
    }
    
    delete catalog;										/*Clean up dynamically allocated memory*/

    return 0;
}
