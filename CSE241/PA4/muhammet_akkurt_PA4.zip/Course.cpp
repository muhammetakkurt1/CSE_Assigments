#include "Course.h"
#include "Student.h"
#include <algorithm>

namespace PA4 {

Course::Course() : code(""), studentCount(0), capacity(5) {					/*Default constructor for Course class*/
    students = new Student *[capacity];								/* Initialize students array with capacity*/
}

Course::Course(const std::string &name, const std::string &code)			/*Constructor with name and code parameters for Course class*/
    : name(name), code(code), studentCount(0), capacity(5) {
    students = new Student *[capacity];										/*Initialize students array with capacity*/
}

Course::~Course() { delete[] students; }									/*Destructor for Course class*/

const std::string &Course::getName() const { return name; }					/*Getter for course name*/		

void Course::setName(const std::string &name) { this->name = name; }		/*Setter for course name*/

const std::string &Course::getCode() const { return code; }					/*Getter for course code*/

void Course::setCode(const std::string &code) { this->code = code; }		/*Setter for course code*/

int Course::getCapacity() const {										/* Getter for course capacity (maximum number of students)*/
    return capacity;
}

void Course::addStudent(Student *student) {							/*Add a student to the course*/
    if (studentCount == capacity) {									/*Check if the students array is full; if so, double its capacity*/
        capacity *= 2;												/*Double the capacity*/
        Student **newStudents = new Student *[capacity];			/*Allocate new memory for the new students array with the increased capacity*/
        for (int i = 0; i < studentCount; ++i) {					/*Copy the existing students to the new array*/
            newStudents[i] = students[i];
        }
        delete[] students;											/*Deallocate the memory for the old students array*/
        students = newStudents;										/*Point the students array to the new memory location*/
    }
    students[studentCount++] = student;								/*Add the student to the end of the students array and increment the student count*/
}

void Course::removeStudent(Student *student) {						/*Remove a student from the course*/
    int index = -1;													/*Initialize the index to -1 to indicate that the student hasn't been found yet*/
    for (int i = 0; i < studentCount; ++i) {						/*Iterate through the students array to find the student*/
        if (students[i] == student) {								/* Check if the current student matches the given student*/
            index = i;												/*Set the index to the current position*/
            break;													/* Break the loop as the student is found*/
        }
    }
    if (index != -1) {											/*If the student is found (index != -1), remove them from the students array*/
        for (int i = index; i < studentCount - 1; ++i) {				/*Shift the rest of the students left to fill the gap*/
            students[i] = students[i + 1];	
        }
        --studentCount;													/*Decrement the student count*/
    }
}

int Course::getStudentCount() const { return studentCount; }		/*Get the current number of students in the course*/

Student *Course::getStudent(int index) {							/*Get a pointer to a student at a specific index in the course's student list*/
    if (index >= 0 && index < studentCount) {						/*Return index if valid number*/
        return students[index];
    }
    return nullptr;													/*Return null if index is not valid*/
}

} 
