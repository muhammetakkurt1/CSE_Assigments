#include "SchoolManagerSystem.h"
#include <iostream>
#include <sstream>
#include <string>

void printMainMenu() {										/*Functions for printing menus*/
    std::cout << "Main_menu" << std::endl;
    std::cout << "0 exit" << std::endl;
    std::cout << "1 student" << std::endl;
    std::cout << "2 course" << std::endl;
    std::cout << "3 list_all_students" << std::endl;
    std::cout << "4 list_all_courses" << std::endl;
}

void printStudentMenu() {								/*Functions for printing menus*/
    std::cout << "0 up" << std::endl;
    std::cout << "1 add_student" << std::endl;
    std::cout << "2 select_student" << std::endl;
}

void printCourseMenu() {								/*Functions for printing menus*/
    std::cout << "0 up" << std::endl;
    std::cout << "1 add_course" << std::endl;
    std::cout << "2 select_course" << std::endl;
}
void printSelectedCourseMenu() {						/*Functions for printing menus*/
    std::cout << "0 up" << std::endl;
    std::cout << "1 delete_course" << std::endl;
    std::cout << "2 list_students_registered_to_the_selected_course" <<std::endl;
}
void printSelectedStudentMenu() {						/*Functions for printing menus*/
    std::cout << "0 up" << std::endl;
	std::cout << "1 delete_student" << std::endl;
	std::cout << "2 add_selected_student_to_a_course" << std::endl;
	std::cout << "3 drop_selected_student_from_a_course" << std::endl;
}
int main() {
    PA4::SchoolManagerSystem mngSystem;						/*Creating school management system object*/
    int choice;

    while (true) {										/*Infinite loop until program exits*/
        printMainMenu();								/*Print main menu*/
        std::cin >> choice;								/*User choice is taken*/

        if (choice == 0) {								/*If the user selects 0, the program is terminated*/
            break;
        } else if (choice == 1) {						/*Student menu*/
            while (true) {
                printStudentMenu();						/*Print student menu*/
                std::cin >> choice;						/*User choice is taken*/
	
                if (choice == 0) {						/* Return to the top menu*/
                    break;
                } else if (choice == 1) {				/*Adding students*/
                    std::string input, name;
				    int ID;
				    std::cin.ignore();					/* Clear remaining '\n' character from previous entry */
				    std::getline(std::cin, input);		/* Get name and ID input from user*/
				    std::stringstream ss(input);		/*Create a stringstream to process the string "input"*/
				    std::string word;					/*The variable to be used to store the word read in each iteration*/
				    std::string lastWord;				/*The variable to be used to store the last word read in each iteration*/
				
				    while (ss >> word) {				/*Process by reading words from stringstream*/
				        if (!lastWord.empty()) {		/*If lastWord is not empty ,so there is a previous word*/
				            name += lastWord + " ";		/*Add the previous word to the name variable and leave a space between the words*/
				        }
				        lastWord = word;				/*Assign current read word to lastWord variable*/
				    }
				
				    ID = std::stoi(lastWord);			/*Convert last word to integer and assign as ID*/
				    mngSystem.addStudent(name, ID);			/*Register the student in the system*/
                } else if (choice == 2) {				/*Student selection process*/	
                    std::string input, name;
				    int ID;
				    std::cin.ignore();					/* Clear remaining '\n' character from previous entry */
				    std::getline(std::cin, input);		/* Get name and ID input from user*/
				    std::stringstream ss(input);		/*Create a stringstream to process the string "input"*/
				    std::string word;					/*The variable to be used to store the word read in each iteration*/
				    std::string lastWord;				/*The variable to be used to store the last word read in each iteration*/
				
				    while (ss >> word) {				/*Process by reading words from stringstream*/
				        if (!lastWord.empty()) {		/*If lastWord is not empty ,so there is a previous word*/
				            name += lastWord + " ";		/*Add the previous word to the name variable and leave a space between the words*/
				        }
				        lastWord = word;				/*Assign current read word to lastWord variable*/
				    }
				
				    ID = std::stoi(lastWord);			/*Convert last word to integer and assign as ID*/
                    PA4::Student *student = mngSystem.getStudent(ID);		/*Retrieve student from system by ID*/

                    if (student) {						/*If student found (if there is a student matching ID)*/
				        while (true) {
				          	printSelectedStudentMenu();		/*Print the selected student menu*/
							int studentChoice;				/*Create a variable to store the user's selection*/
				            std::cin >> studentChoice;		/*Get user's choice*/
				
				            if (studentChoice == 0) {		/* Return to the top menu*/
				                break;
				            } else if (studentChoice == 1) {		/*If selection is "1"*/
				                mngSystem.deleteStudent(ID);			/*Delete the student*/
				                break;							/* Return to the top menu*/
				            } else if (studentChoice == 2) {  		 /*If selection is "2" (enroll selected student in a course)*/
							    PA4::Course **availableCourses;		/*Create a pointer to an array of pointers pointing to available courses*/
							    int availableCourseCount = mngSystem.listAvailableCoursesForStudent(ID, availableCourses);	/*Get the number of courses available to the student and their pointers*/

							    int courseIndex;				/*Create a variable to store the user's selection*/
							    std::cin >> courseIndex;		/*Get user's choice*/
							    if (courseIndex >= 1 && courseIndex <= availableCourseCount) {		/*If the selected course is a valid option*/
							        PA4::Course *course = availableCourses[courseIndex - 1];		/*get pointer to user selected course*/
							        student->addCourse(course);							/*Enroll student in class*/
							        course->addStudent(student);						/*Add student to course student list*/
							    } 
							    delete[] availableCourses;				/*Delete the list of available courses*/
							}
							else if (studentChoice == 3) {			/*If selection is "3" (remove selected student from a course)*/
							    PA4::Course** enrolledCourses;		/*Create a pointer to an array of pointers pointing to enrolled courses*/
							    int enrolledCourseCount = student->listCourses(enrolledCourses);			/*Get the number of courses the student is enrolled in*/
							
							    if (enrolledCourseCount > 0) {							/*If the student is enrolled in at least one course*/
							        for (int i = 0; i < enrolledCourseCount; i++) {				/*List the courses (s)he is enrolled in*/
							            std::cout << (i + 1) << " " << enrolledCourses[i]->getCode() << " " << enrolledCourses[i]->getName() << std::endl;
							        }
							
							        int courseIndex;
							        std::cin >> courseIndex;		/*Prompt user to enter index for course selection*/
							
							        if (courseIndex >= 1 && courseIndex <= enrolledCourseCount) {		/*If the selection is valid*/
							            PA4::Course *course = enrolledCourses[courseIndex - 1];			/*get pointer to user selected course*/
							            student->dropCourse(course);							/*Take the student out of this course*/
							            course->removeStudent(student);							/*Remove this student from the course's student list.*/
							        }
							    }
								delete[] enrolledCourses;						/*Free dynamically allocated "enrolledCourses" memory*/
							}
				        }
				    }
                }
            }
        } else if (choice == 2) {		/* Course menu*/
		while (true) {
	        printCourseMenu();				/*Print the course menu*/
	        std::cin >> choice;				/*User choice is taken*/
	
	        if (choice == 0) {				/* Return to the top menu*/
	            break;
	        } else if (choice == 1) {		/*Course add process*/
	            std::string name;
	            std::string code;
	            std::cin.ignore();					/* Clear remaining '\n' character from previous entry */
	            std::getline(std::cin, name);					/*Get course name and code from user as input*/
	            code = name.substr(0, name.find(" "));			/*Get course code (up to space character)*/
	            name = name.substr(name.find(" ") + 1); 		/*Get course name (part after space character)*/
	            mngSystem.addCourse(name, code);						/*Add the course to the system*/
	        } else if (choice == 2) {		/*Course selection process*/	
	            std::string code;
			    std::string name;		
			    std::cin.ignore();					/* Clear remaining '\n' character from previous entry */
			    std::getline(std::cin, name);					/*Get course name and code from user as input*/
			    code = name.substr(0, name.find(" "));			/*Get course code (up to space character)*/
			    name = name.substr(name.find(" ") + 1);			/*Get course name (part after space character)*/
			    PA4::Course *selectedCourse = mngSystem.getCourse(code);		/*Obtain the registered course in the system by calling its code*/
	
	            if (selectedCourse) {					/*If the selected course is found*/
	                while (true) {					/*Start continuous loop for selected course menu*/
	                    printSelectedCourseMenu();		/*Print the selected course menu*/
	                    std::cin >> choice;				/*Get user's choice*/
	
	                    if (choice == 0) {				/* Return to the top menu*/
	                        break;
	                    } else if (choice == 1) {				/*If selection is "1"*/
	                        mngSystem.deleteCourse(code);				/*Delete the course from the system*/
	                        break;
	                    } else if (choice == 2) {				/*If selection is "2"*/
	                        mngSystem.listStudentsInCourse(code);		/*List students in the course*/
	                    }
	                }
	            }
	        }
	    }
		}else if (choice == 3) {			/*List all students*/	
		        mngSystem.listAllStudents(); 	/*Call the listAllStudents function*/
		}else if (choice == 4) {			/*List all courses*/
		        mngSystem.listAllCourses(); 	/* Call the listAllCourses function*/
		        }
	}

    return 0;
}
