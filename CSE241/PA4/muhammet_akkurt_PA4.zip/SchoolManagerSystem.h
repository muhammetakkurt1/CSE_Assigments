#ifndef SCHOOLMANAGERSYSTEM_H
#define SCHOOLMANAGERSYSTEM_H

#include "Student.h"
#include "Course.h"
#include <string>

namespace PA4 {

class SchoolManagerSystem {
public:
    SchoolManagerSystem();						/* Default constructor*/
    ~SchoolManagerSystem();						/*Destructor*/

    Student *addStudent(const std::string &name, int ID);			/*Add a student with a given name and ID to the school management system*/
    void deleteStudent(int ID);										/*Remove a student with a given ID from the school management system*/
    Student *getStudent(int ID);									/*Get the student object with a given ID, or return nullptr if not found*/

    Course *addCourse(const std::string &name, const std::string &code);		/*Add a course with a given name and code to the school management system*/
	void deleteCourse(const std::string &code);									/* Remove a course with a given code from the school management system*/
	Course *getCourse(const std::string &code);									/*Get the course object with a given code, or return nullptr if not found*/


    void addStudentToCourse(int studentID, int courseCode);							/*Add a student with a given ID to a course with a given code*/
    void removeStudentFromCourse(int studentID, int courseCode);					/*Remove a student with a given ID from a course with a given code*/
    void listStudentsInCourse(const std::string &courseCode);						/* List all students enrolled in a course with a given code*/
    int listAvailableCoursesForStudent(int studentID, Course **&availableCourses);		/*Get the number of available courses for a student with a given ID, and store them in the availableCourses array*/
    void listCoursesForStudent(int studentID);										/* List all courses that a student with a given ID is enrolled in*/
    void listAllStudents() const;													/*List all students in the school management system*/
	void listAllCourses() const;													/*List all courses in the school management system*/
	

private:
  	void resizeStudentArray(int newSize);											/* Resize the student array to a new size*/
    void resizeCourseArray(int newSize);											/*Resize the course array to a new size*/

    Student** studentReferences;													/*Arrays to store pointers to student and course objects*/
    Course** courseReferences;
    int numStudents;																/*The number of students and courses in the school management system*/
    int numCourses;
    int studentArraySize;															/*The current sizes of the student and course arrays*/
    int courseArraySize;
};

} 

#endif 

