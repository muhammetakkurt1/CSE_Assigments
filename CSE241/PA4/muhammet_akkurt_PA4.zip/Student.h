#ifndef STUDENT_H
#define STUDENT_H

#include <string>

namespace PA4 {

class Course;										/*Forward declaration of the Course class*/

class Student {										/*Student class definition*/	
public:
    Student();										/* Default constructor*/
    Student(const std::string &name, int ID);		/*constructor that takes name and id*/
    ~Student();										/*Destructor*/

    const std::string &getName() const;				/*Function to get the student's name*/
    void setName(const std::string &name);			/*Function to set the student's name*/
		
    int getID() const;								/*Function to get the student's ID*/
    void setID(int ID);								/*Function to set the student's ID*/
    
	int listCourses(Course **&enrolledCourses);		/*Function to get the list of enrolled courses*/
	bool isEnrolledInCourse(Course *course) const;	/*Function to check if the student is enrolled in a course*/	
	void dropCourse(Course *course);				/* Function to drop a course*/
    void addCourse(Course *course);					/*Function to add a course*/
    void removeCourse(Course *course);				/*Function to remove a course*/
    int getCourseCount() const;						/* Function to get the number of courses*/
    Course *getCourse(int index);					/*Function to get a course at the specified index*/

private:
    std::string name;								/* Student's name*/
    int ID;											/* Student's ID*/
    Course **courses;								/* Pointer to an array of course pointers*/
    int courseCount;								/*Number of enrolled courses*/
    int capacity;									/* Capacity of the courses array*/
};

} 

#endif

