#ifndef COURSE_H
#define COURSE_H

#include <string>

namespace PA4 {

class Student;									 /*Forward declaration for Student class*/

class Course {									/*Course class definition*/
public:
    Course();									/*Default constructor*/
    Course(const std::string &name, const std::string &code);			/*Constructor with name and code parameters*/
    ~Course();									/*Destructor*/

    const std::string &getName() const;					/*Getter for course name*/
    void setName(const std::string &name);				/*Setter for course name*/

    const std::string &getCode() const;					/*Getter for course code*/
    void setCode(const std::string &code);				/*Setter for course code*/
    int getCapacity() const;							/* Getter for course capacity (maximum number of students)*/

    void addStudent(Student *student);					/*Add a student to the course*/
    void removeStudent(Student *student);				/*Remove a student from the course*/
    int getStudentCount() const;						/*Get the current number of students in the course*/
    Student *getStudent(int index);						/*Get a pointer to a student at a specific index in the course's student list*/	

private:
    std::string name;							/*Course name*/
    std::string code;							/*Course code*/
    Student **students;							/*Pointer to an array of pointers to students enrolled in the course*/
    int studentCount;							/* Current number of students in the course*/
    int capacity;								/*Maximum number of students the course can hold*/
};	

} 

#endif 

