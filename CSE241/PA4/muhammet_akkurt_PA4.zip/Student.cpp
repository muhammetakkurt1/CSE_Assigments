#include "Student.h"
#include "Course.h"
#include <iostream>
#include <algorithm>

namespace PA4 {

Student::Student() : ID(0), courseCount(0), capacity(5) {		/*Default constructor*/
    courses = new Course *[capacity];							/* Initialize courses with initial capacity*/
}

Student::Student(const std::string &name, int ID)				/* Constructor with name and ID parameters*/
    : name(name), ID(ID), courseCount(0), capacity(5) {			
    courses = new Course *[capacity];							/* Initialize courses with initial capacity*/
}

Student::~Student() { 							/* Destructor*/
		delete[] courses; 						/*Deallocate memory for courses*/
		}					

const std::string &Student::getName() const { return name; }		/*Getter for student name*/

void Student::setName(const std::string &name) { this->name = name; }		/*Setter for student name*/

int Student::getID() const { return ID; }							/* Getter for student ID*/

void Student::setID(int ID) { this->ID = ID; }						/*Setter for student ID*/

int Student::getCourseCount() const { return courseCount; }					/* Getter for the number of courses*/

void Student::addCourse(Course *course) {							/*Add course to student's course list*/
    if (courseCount == capacity) {									/* Check if the course list is full */
        capacity *= 2;												 /* Double the capacity of the course list */
        Course **newCourses = new Course *[capacity];				/* Create a new array with the increased capacity */
        
		for (int i = 0; i < courseCount; ++i) {					/* Copy the existing courses into the new array */
            newCourses[i] = courses[i];
        }
        delete[] courses;									/* Delete the old course array to free up memory */
        courses = newCourses;								/* Update the courses pointer to point to the new array */
    }
    courses[courseCount++] = course;					 /*Add course to the end of the course list*/
}

void Student::removeCourse(Course *course) {			/*Remove course from student's course list*/
    int index = -1;
    for (int i = 0; i < courseCount; ++i) {				/*Find the course in the list*/
        if (courses[i] == course) {
            index = i;
            break;
        }
    }
    if (index != -1) {									/* If the course is found, shift the remaining courses to the left to fill the gap */
        for (int i = index; i < courseCount - 1; ++i) {
            courses[i] = courses[i + 1];	
        }
        --courseCount;						/* Decrement the course count as the course has been removed */
    }
}
int Student::listCourses(Course **&enrolledCourses) {		/* List all courses the student is enrolled in */
    enrolledCourses = new Course*[courseCount];				  /* Allocate memory for the array of enrolled courses */
    for (int i = 0; i < courseCount; i++) {					 /* Copy the courses from the student's list of courses to the enrolledCourses array */
        enrolledCourses[i] = courses[i];
    }
    return courseCount;							 /* Return the number of courses the student is enrolled in */
}

void Student::dropCourse(Course *course) {				/* Drop a course and remove it from the course's student list*/
    removeCourse(course);						  /* Remove the course from the student's list of courses */
    course->removeStudent(this);					/* Remove the student from the list of students in the course */
}
bool Student::isEnrolledInCourse(Course *course) const {					/*Check if student is enrolled in a specific course*/
    /* Search for the course in the student's list of courses */
    /* If the course is found, return true; otherwise, return false */
	return std::find(courses, courses + courseCount, course) != courses + courseCount;
}

Course *Student::getCourse(int index) {					/*Get a specific course by index*/
    if (index >= 0 && index < courseCount) {		/*Return index if valid number*/
        return courses[index];
    }
    return nullptr;								/*Return null if index is not valid*/
}

}

