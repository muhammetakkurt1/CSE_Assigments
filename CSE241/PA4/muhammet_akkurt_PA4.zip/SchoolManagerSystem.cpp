#include "SchoolManagerSystem.h"
#include <iostream>
#include <algorithm>
namespace PA4 {
SchoolManagerSystem::SchoolManagerSystem() : studentArraySize(10), courseArraySize(10), numStudents(0), numCourses(0) {			/*Default constructor for SchoolManagerSystem*/
    studentReferences = new Student*[studentArraySize];										/*Allocate memory for the student references array*/
    courseReferences = new Course*[courseArraySize];										/*Allocate memory for the course references array*/
}

SchoolManagerSystem::~SchoolManagerSystem() {		/*Destructor for SchoolManagerSystem class*/
    for (int i = 0; i < numStudents; i++) {			/*Loop through the student references array and delete each student object*/
        delete studentReferences[i];
    }
    for (int i = 0; i < numCourses; i++) {			/*Loop through the course references array and delete each course object*/
        delete courseReferences[i];
    }
    delete[] studentReferences;						/*Delete the student references array, releasing the memory*/
    delete[] courseReferences;						/*Delete the course references array, releasing the memory*/
}

Student* SchoolManagerSystem::addStudent(const std::string& name, int ID) {			/*Add a student to the system*/
    Student* newStudent = new Student(name, ID);								/*Create a new Student object with the given name and ID*/
    if (numStudents == studentArraySize) {										/*If the number of students is equal to the size of the student array*/
        resizeStudentArray(studentArraySize * 2);								/* resize the student array by doubling its size*/
    }
    studentReferences[numStudents++] = newStudent;						/*Add the new student to the student references array and increment the number of students*/
    return newStudent;													/*Return the newly added student object*/
}

void SchoolManagerSystem::deleteStudent(int ID) {
    int index = -1;											/*Delete a student from the system based on the student ID*/
    for (int i = 0; i < numStudents; ++i) {					/*Find the index of the student with the given ID in the student references array*/
        if (studentReferences[i]->getID() == ID) {
            index = i;
            break;
        }
    }
    if (index != -1) {										/*If the student is found, delete the student object,*/
        delete studentReferences[index];
        for (int i = index; i < numStudents - 1; ++i) {				/*shift the remaining students in the array to fill the gap*/
            studentReferences[i] = studentReferences[i + 1];
        }
        --numStudents;									/*decrement the number of students*/
    }
}

Student* SchoolManagerSystem::getStudent(int ID) {		/*Get a student from the system by their ID*/
    for (int i = 0; i < numStudents; ++i) {			    /*Iterate through the student references array*/
        if (studentReferences[i]->getID() == ID) {		/*If a student with the given ID is found, return the student object*/
            return studentReferences[i];
        }
    }
    return nullptr;									/*If no student is found with the given ID, return nullptr*/
}

Course* SchoolManagerSystem::addCourse(const std::string& name, const std::string &code) {		/*	Add a course to the system with the given name and course code */
    Course* newCourse = new Course(name, code);													/*Create a new Course object with the provided name and course code*/
    if (numCourses == courseArraySize) {									/*If the number of courses is equal to the size of the course array*/
        resizeCourseArray(courseArraySize * 2);								/*resize the course array by doubling its size*/
    }
    courseReferences[numCourses++] = newCourse;								/*Add the new course to the course references array and increment the number of courses*/
    return newCourse;														/*Return the newly added course object*/
}	
void SchoolManagerSystem::deleteCourse(const std::string &code) {			/* Delete a course from the system using the given course code*/
    int index = -1;															/*Initialize the index of the course to be deleted as -1*/
    for (int i = 0; i < numCourses; ++i) {									/*Iterate through the course references array to find the course*/
        if (courseReferences[i]->getCode() == code) {						/*If the course with the given code is found, set the index and break the loop*/
            index = i;
            break;
        }
    }
    if (index != -1) {														/*If the course is found , delete the course and shift the remaining courses in the array to fill the gap*/
        delete courseReferences[index];
        for (int i = index; i < numCourses - 1; ++i) {
            courseReferences[i] = courseReferences[i + 1];
        }
        --numCourses;												/*Decrement the number of courses*/
    }
}

Course* SchoolManagerSystem::getCourse(const std::string &code) {			/*Get a course from the system using the given course code*/
    for (int i = 0; i < numCourses; ++i) {									/*Iterate through the course references array to find the course*/
        if (courseReferences[i]->getCode() == code) {						/* If a course with the given code is found, return the course object*/
            return courseReferences[i];
        }
    }
    return nullptr;													/*If no course is found with the given code, return nullptr*/
}

void SchoolManagerSystem::resizeStudentArray(int newSize) {						/* Resize the student array to the new size provided*/
    Student** newStudentArray = new Student*[newSize];							/*Create a new student array with the new size*/
    for (int i = 0; i < numStudents; i++) {										/*Copy the existing student references to the new student array*/
        newStudentArray[i] = studentReferences[i];
    }
    delete[] studentReferences;													/*Delete the old student references array*/
    studentReferences = newStudentArray;										/*Assign the new student array to the student references and update the student array size*/
    studentArraySize = newSize;
}
void SchoolManagerSystem::resizeCourseArray(int newSize) {						/*Resize the course array to the new size provided*/
    Course** newCourseArray = new Course*[newSize];								/*Create a new course array with the new size*/
    for (int i = 0; i < numCourses; i++) {										/*Copy the existing course references to the new course array*/
        newCourseArray[i] = courseReferences[i];
    }
    delete[] courseReferences;													/*Delete the old course references array*/
    courseReferences = newCourseArray;											/*Assign the new course array to the course references and update the course array size*/
    courseArraySize = newSize;
}
int SchoolManagerSystem::listAvailableCoursesForStudent(int studentID, Course **&availableCourses) {
    Student *student = getStudent(studentID);								/* Find the student with the given studentID*/
    if (!student) {															/*If the student is not found, return 0	*/			
        return 0;
    }

    int availableCourseCount = 0;												/*Initialize a counter for the available courses for the student*/

    for (int i = 0; i < numCourses; i++) {										/* Iterate through the courses in the system*/
        Course *course = courseReferences[i];
        if (course->getStudentCount() < course->getCapacity()) {				/*Check if the course has space for more students*/
            if (student->getCourseCount() == 0 || !student->isEnrolledInCourse(course)) {		/*Check if the student is not already enrolled in the course*/
                availableCourseCount++;										/*Increase counter*/
            }
        }
    }

    availableCourses = new Course*[availableCourseCount];					/*Allocate memory for the array of available courses*/
    int index = 0;

    for (int i = 0; i < numCourses; i++) {									/*Iterate through the courses in the system again*/
        Course *course = courseReferences[i];
        if (course->getStudentCount() < course->getCapacity()) {			/*Check if the course has space for more students and the student is not already enrolled*/
            if (student->getCourseCount() == 0 || !student->isEnrolledInCourse(course)) {
                availableCourses[index] = course;											/*Add the course to the available courses array and print its information*/
                std::cout << (index + 1) << " " << course->getCode() << " " << course->getName() << std::endl;
                index++;
            }
        }
    }
    return availableCourseCount;						/*Return the count of available courses for the student*/
}	

void SchoolManagerSystem::listCoursesForStudent(int studentID) {
    Student* student = getStudent(studentID);							/* Find the student with the given studentID*/
    if (student) {														/*If the student is found*/
        for (int i = 0; i < student->getCourseCount(); ++i) {			/*Iterate through the courses the student is enrolled in*/
            Course* course = student->getCourse(i);						/*Get the course and print its code and name*/
            std::cout << course->getCode() << " " << course->getName() << std::endl;
        }
    }
}

void SchoolManagerSystem::listStudentsInCourse(const std::string &courseCode) {
    Course *course = getCourse(courseCode);								/* Find the course with the given courseCode*/
    if (course) {														/*If the course is found*/
        for (int i = 0; i < course->getStudentCount(); ++i) {			/* Iterate through the students enrolled in the course*/
            Student *student = course->getStudent(i);					/*Get the student and print their name and ID*/
            std::cout << student->getName() << " " << student->getID() << std::endl;
        }
    }
}


void SchoolManagerSystem::listAllStudents() const {	
    for (int i = 0; i < numStudents; ++i) {				/*Iterate through all students in the system*/ 
        std::cout << studentReferences[i]->getName() << " " << studentReferences[i]->getID() << std::endl;  /*Print each student's name and ID*/
    }
}

void SchoolManagerSystem::listAllCourses() const {
    for (int i = 0; i < numCourses; ++i) {				/*Iterate through all courses in the system*/ 
        std::cout << courseReferences[i]->getCode() << " " << courseReferences[i]->getName() << std::endl;	/*Print each course's code and name*/
    }
}
} 

